"""
Cette fonction contiendra toutes les fonctions utiles au projet

PS: N'hésite pas d'en rajouter si nécessaire -- :)
"""